package com.example.ex1calculator;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

public class ScaleTrans extends AppCompatActivity {
    private List<String> List = null;
    private ArrayAdapter<String> Adapter = null;
    private Spinner Spinner= null;
    private Spinner Spinner2 = null;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scale);
        final EditText editText = (EditText)findViewById(R.id.input);
        final TextView textView = (TextView)findViewById(R.id.result);
        Button btn_return = (Button)findViewById(R.id.returntolast);
        Button btn_submit = (Button)findViewById(R.id.submit);


        btn_return.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ScaleTrans.this,MainActivity.class);
                startActivity(i);
            }
        });

        final String[] inputScale = {null};
        final String[] outputScale = {null};
        Spinner = super.findViewById(R.id.choose1);
        Spinner2 = super.findViewById(R.id.choose2);
        List = new ArrayList<String>();
        List.add("Binary(2)");
        List.add("Octonary(8)");
        List.add("Decimalism(10)");
        List.add("Hexadecimal(16)");
        Adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,List);
        Adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner.setAdapter(Adapter);
        Spinner2.setAdapter(Adapter);

        Spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String input = Adapter.getItem(i);
                inputScale[0] = input;
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        Spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String output = Adapter.getItem(i);
                outputScale[0] = output;
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = editText.getText().toString();
                int num = 0;
                if (currentText == null || currentText == "0")
                {
                    textView.setText("0");
                } else
                    {
                        switch (inputScale[0])
                        {
                            case "Binary(2)":
                                switch (outputScale[0]) {
                                    case "Binary(2)":
                                        break;
                                    case "Octonary(8)":
                                        num = Integer.parseInt(currentText,2);
                                        currentText = Integer.toOctalString(num);
                                        break;
                                    case "Decimalism(10)":
                                        num = Integer.parseInt(currentText,2);
                                        NumberFormat numberFormat = NumberFormat.getInstance();
                                        numberFormat.setGroupingUsed(false);
                                        currentText = numberFormat.format(num);
                                        break;
                                    case "Hexadecimal(16)":
                                        num = Integer.parseInt(currentText,2);
                                        currentText = Integer.toHexString(num);
                                        break;
                                }
                                break;
                            case "Octonary(8)":
                                switch (outputScale[0]) {
                                    case "Binary(2)":
                                        num = Integer.parseInt(currentText,8);
                                        currentText = Integer.toBinaryString(num);
                                        break;
                                    case "Octonary(8)":
                                        break;
                                    case "Decimalism(10)":
                                        num = Integer.parseInt(currentText,8);
                                        NumberFormat numberFormat = NumberFormat.getInstance();
                                        numberFormat.setGroupingUsed(false);
                                        currentText = numberFormat.format(num);
                                        break;
                                    case "Hexadecimal(16)":
                                        num = Integer.parseInt(currentText,8);
                                        currentText = Integer.toHexString(num);
                                        break;
                                }
                                break;
                            case "Decimalism(10)":
                                switch (outputScale[0]) {
                                    case "Binary(2)":
                                        num = Integer.parseInt(currentText,10);
                                        currentText = Integer.toBinaryString(num);
                                        break;
                                    case "Octonary(8)":
                                        num = Integer.parseInt(currentText,10);
                                        currentText = Integer.toOctalString(num);
                                        break;
                                    case "Decimalism(10)":
                                        break;
                                    case "Hexadecimal(16)":
                                        num = Integer.parseInt(currentText,10);
                                        currentText = Integer.toHexString(num);
                                        break;
                                }
                                break;
                            case "Hexadecimal(16)":
                                switch (outputScale[0]) {
                                    case "Binary(2)":
                                        num = Integer.parseInt(currentText,16);
                                        currentText = Integer.toBinaryString(num);
                                        break;
                                    case "Octonary(8)":
                                        num = Integer.parseInt(currentText,16);
                                        currentText = Integer.toOctalString(num);
                                        break;
                                    case "Decimalism(10)":
                                        num = Integer.parseInt(currentText,16);
                                        NumberFormat numberFormat = NumberFormat.getInstance();
                                        numberFormat.setGroupingUsed(false);
                                        currentText = numberFormat.format(num);
                                        break;
                                    case "Hexadecimal(16)":
                                        break;
                                }
                                break;
                    }
                }
                textView.setText(currentText);

            }
        });
    }
}

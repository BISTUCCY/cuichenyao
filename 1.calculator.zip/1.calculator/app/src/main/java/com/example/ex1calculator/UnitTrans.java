package com.example.ex1calculator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class UnitTrans extends AppCompatActivity {
    private List<String> ListUnit = null;
    private List<String> ListLength = null;
    private List<String> ListArea = null;
    private List<String> ListTime = null;
    private List<String> ListWeight = null;
    private ArrayAdapter<String> Adapter1 = null;
    private ArrayAdapter<String> Adapter2 = null;
    private ArrayAdapter<String> Adapter3 = null;
    private ArrayAdapter<String> Adapter4 = null;
    private ArrayAdapter<String> Adapter5 = null;
    private Spinner Spinner= null;
    private Spinner Spinner2 = null;
    private Spinner Spinner3 = null;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.unit);
        final String[] inputScaleUnit = {null};
        final String[] inputUnit = {null};
        final String[] outputUnit = {null};

        Spinner = super.findViewById(R.id.chose1);
        Spinner2 = super.findViewById(R.id.chose2);
        Spinner3 = super.findViewById(R.id.chose3);

        ListUnit = new ArrayList<String>();
        ListUnit.add("Length");
        ListUnit.add("Area");
        ListUnit.add("Time");
        ListUnit.add("Weight");

        ListLength = new ArrayList<String>();
        ListLength.add("nm");
        ListLength.add("μm");
        ListLength.add("mm");
        ListLength.add("cm");
        ListLength.add("m");
        ListLength.add("km");

        ListArea = new ArrayList<String>();
        ListArea.add("cm²");
        ListArea.add("m²");
        ListArea.add("hm²");
        ListArea.add("km²");

        ListTime = new ArrayList<String>();
        ListTime.add("Year");
        ListTime.add("Month(30days)");
        ListTime.add("Day");
        ListTime.add("Hour");
        ListTime.add("Minute");
        ListTime.add("Second");

        ListWeight = new ArrayList<String>();
        ListWeight.add("t");
        ListWeight.add("kg");
        ListWeight.add("g");
        ListWeight.add("mg");
        Button btn_return = (Button)findViewById(R.id.returntl);
        Button btn_submit = (Button)findViewById(R.id.submit1);
        final EditText number = (EditText)findViewById(R.id.inputnum);
        final TextView result = (TextView)findViewById(R.id.result1);

        Adapter1 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,ListUnit);
        Adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        Adapter2 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,ListLength);
        Adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        Adapter3 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,ListArea);
        Adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        Adapter4 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,ListTime);
        Adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        Adapter5 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,ListWeight);
        Adapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        Spinner.setAdapter(Adapter1);
        Spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String input = Adapter1.getItem(i);
                inputScaleUnit[0] = input;
                switch (input){
                    case "Length":
                        Spinner2.setAdapter(Adapter2);
                        Spinner3.setAdapter(Adapter2);
                        break;
                    case "Area":
                        Spinner2.setAdapter(Adapter3);
                        Spinner3.setAdapter(Adapter3);
                        break;
                    case "Time":
                        Spinner2.setAdapter(Adapter4);
                        Spinner3.setAdapter(Adapter4);
                        break;
                    case "Weight":
                        Spinner2.setAdapter(Adapter5);
                        Spinner3.setAdapter(Adapter5);
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        Spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (inputScaleUnit[0])
                {
                    case "Length":
                        String length = Adapter2.getItem(i);
                        inputUnit[0] = length;
                        break;
                    case "Area":
                        String Area = Adapter3.getItem(i);
                        inputUnit[0] = Area;
                        break;
                    case "Time":
                        String Time = Adapter4.getItem(i);
                        inputUnit[0] = Time;
                        break;
                    case "Weight":
                        String Weight = Adapter5.getItem(i);
                        inputUnit[0] = Weight;
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        Spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (inputScaleUnit[0])
                {
                    case "Length":
                        String length = Adapter2.getItem(i);
                        outputUnit[0] = length;
                        break;
                    case "Area":
                        String Area = Adapter3.getItem(i);
                        outputUnit[0] = Area;
                        break;
                    case "Time":
                        String Time = Adapter4.getItem(i);
                        outputUnit[0] = Time;
                        break;
                    case "Weight":
                        String Weight = Adapter5.getItem(i);
                        outputUnit[0] = Weight;
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        btn_return.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(UnitTrans.this,MainActivity.class);
                startActivity(i);
            }
        });
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data = number.getText().toString();
                double data1 = Double.parseDouble(data);
                NumberFormat numberFormat = NumberFormat.getInstance();
                numberFormat.setMaximumFractionDigits(20);
                switch(inputUnit[0]){
                    case "nm":
                        switch (outputUnit[0]){
                            case"μm":
                                data1=data1/Math.pow(10,3);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "mm":
                                data1=data1/Math.pow(10,6);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                            case "cm":
                                data1=data1/Math.pow(10,7);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                            case "m":
                                data1=data1/Math.pow(10,9);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                            case "km":
                                data1=data1/Math.pow(10,12);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "μm":
                        switch (outputUnit[0]){
                            case"nm":
                                data1=data1*1000;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "mm":
                                data1=data1/Math.pow(10,3);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "cm":
                                data1=data1/Math.pow(10,4);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "m":
                                data1=data1/Math.pow(10,6);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                            case "km":
                                data1=data1/Math.pow(10,9);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "mm":
                        switch (outputUnit[0]){
                            case"nm":
                                data1=data1*Math.pow(10,6);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                            case "μm":
                                data1=data1*Math.pow(10,3);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "cm":
                                data1=data1/Math.pow(10,1);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "m":
                                data1=data1/Math.pow(10,3);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "km":
                                data1=data1/Math.pow(10,6);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "cm":
                        switch (outputUnit[0]){
                            case"nm":
                                data1=data1*Math.pow(10,7);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                            case "μm":
                                data1=data1*Math.pow(10,4);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "mm":
                                data1=data1*Math.pow(10,1);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "m":
                                data1=data1/Math.pow(10,2);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "km":
                                data1=data1/Math.pow(10,5);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "m":
                        switch (outputUnit[0]){
                            case"nm":
                                data1=data1*Math.pow(10,9);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                            case "μm":
                                data1=data1*Math.pow(10,6);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                            case "mm":
                                data1=data1*Math.pow(10,3);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "cm":
                                data1=data1*Math.pow(10,2);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "km":
                                data1=data1/Math.pow(10,3);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "km":
                        switch (outputUnit[0]){
                            case"nm":
                                data1=data1*Math.pow(10,12);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                            case "μm":
                                data1=data1*Math.pow(10,9);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                            case "mm":
                                data1=data1*Math.pow(10,6);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                            case "cm":
                                data1=data1*Math.pow(10,5);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "m":
                                data1=data1*Math.pow(10,3);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "cm²":
                        switch (outputUnit[0])
                        {
                            case "m²":
                                data1=data1/Math.pow(10,4);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "hm²":
                                data1=data1/Math.pow(10,8);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                            case "km²":
                                data1=data1/Math.pow(10,10);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "m²":
                        switch (outputUnit[0])
                        {
                            case "cm²":
                                data1=data1*Math.pow(10,4);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "hm²":
                                data1=data1/Math.pow(10,4);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "km²":
                                data1=data1/Math.pow(10,6);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "hm²":
                        switch (outputUnit[0])
                        {
                            case "cm²":
                                data1=data1*Math.pow(10,8);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                            case "m²":
                                data1=data1*Math.pow(10,4);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "km²":
                                data1=data1/Math.pow(10,2);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "km²":
                        switch (outputUnit[0])
                        {
                            case "cm²":
                                data1=data1*Math.pow(10,10);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                            case "m²":
                                data1=data1*Math.pow(10,6);
                                numberFormat.setGroupingUsed(true);
                                data = numberFormat.format(data1);
                                break;
                            case "hm²":
                                data1=data1*Math.pow(10,2);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "Year":
                        switch (outputUnit[0])
                        {
                            case "Month(30days)":
                                data1=data1*12;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Day":
                                data1=data1*365;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Hour":
                                data1=data1*365*24;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Minute":
                                data1=data1*365*24*60;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Second":
                                data1=data1*365*24*60*60;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "Month(30days)":
                        switch (outputUnit[0])
                        {
                            case "Year":
                                data1=data1/12;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Day":
                                data1=data1*30;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Hour":
                                data1=data1*30*24;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Minute":
                                data1=data1*30*24*60;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Second":
                                data1=data1*30*24*60*60;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "Day":
                        switch (outputUnit[0])
                        {
                            case "Year":
                                data1=data1/365;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Month(30days)":
                                data1=data1/30;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Hour":
                                data1=data1*24;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Minute":
                                data1=data1*24*60;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Second":
                                data1=data1*24*60*60;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "Hour":
                        switch (outputUnit[0])
                        {
                            case "Year":
                                data1=data1/24/365;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Month(30days)":
                                data1=data1/24/30;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Day":
                                data1=data1/24;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Minute":
                                data1=data1*60;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Second":
                                data1=data1*60*60;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "Minute":
                        switch (outputUnit[0])
                        {
                            case "Year":
                                data1=data1/60/24/365;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Month(30days)":
                                data1=data1/60/24/30;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Day":
                                data1=data1/60/24;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Hour":
                                data1=data1/60;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Second":
                                data1=data1*60;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "Second":
                        switch (outputUnit[0])
                        {
                            case "Year":
                                data1=data1/60/60/24/365;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Month(30days)":
                                data1=data1/60/60/24/30;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Day":
                                data1=data1/60/60/24;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Hour":
                                data1=data1/60/60;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "Minute":
                                data1=data1/60;
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "t":
                        switch (outputUnit[0])
                        {
                            case "kg":
                                data1=data1*Math.pow(10,3);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "g":
                                data1=data1*Math.pow(10,6);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "mg":
                                data1=data1*Math.pow(10,9);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "kg":
                        switch (outputUnit[0])
                        {
                            case "t":
                                data1=data1/Math.pow(10,3);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "g":
                                data1=data1*Math.pow(10,3);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "mg":
                                data1=data1*Math.pow(10,6);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "g":
                        switch (outputUnit[0])
                        {
                            case "t":
                                data1=data1/Math.pow(10,6);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "kg":
                                data1=data1/Math.pow(10,3);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "mg":
                                data1=data1*Math.pow(10,3);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                    case "mg":
                        switch (outputUnit[0])
                        {
                            case "t":
                                data1=data1/Math.pow(10,9);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "kg":
                                data1=data1/Math.pow(10,6);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                            case "g":
                                data1=data1/Math.pow(10,3);
                                numberFormat.setGroupingUsed(false);
                                data = numberFormat.format(data1);
                                break;
                        }
                        break;
                }
                result.setText(data);
            }
        });
    }
}

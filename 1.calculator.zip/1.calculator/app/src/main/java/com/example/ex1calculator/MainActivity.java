package com.example.ex1calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.backup.RestoreObserver;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.NumberFormat;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity  {
    private static int check_function = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final TextView textblock = (TextView) findViewById(R.id.cal);
        Button btn0 = (Button) findViewById(R.id.bt_0);
        Button btn1 = (Button) findViewById(R.id.bt_1);
        Button btn2 = (Button) findViewById(R.id.bt_2);
        Button btn3 = (Button) findViewById(R.id.bt_3);
        Button btn4 = (Button) findViewById(R.id.bt_4);
        Button btn5 = (Button) findViewById(R.id.bt_5);
        Button btn6 = (Button) findViewById(R.id.bt_6);
        Button btn7 = (Button) findViewById(R.id.bt_7);
        Button btn8 = (Button) findViewById(R.id.bt_8);
        Button btn9 = (Button) findViewById(R.id.bt_9);

        Button btnplus = (Button) findViewById(R.id.bt_plus);
        Button btnminus = (Button) findViewById(R.id.bt_minus);
        Button btntime = (Button) findViewById(R.id.bt_time);
        Button btndiv = (Button) findViewById(R.id.bt_divide);

        Button btnclear = (Button) findViewById(R.id.bt_clear);
        Button btnbackspace = (Button) findViewById(R.id.bt_backspace);

        Button btnpoint = (Button) findViewById(R.id.bt_point);
        Button btnpercent = (Button) findViewById(R.id.bt_percent);
        Button btnequal = (Button) findViewById(R.id.bt_equal);

        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.land);

        Button btnscale = (Button) findViewById(R.id.scale);
        Button btnunit = (Button) findViewById(R.id.unit);

        Button btnlb = (Button) findViewById(R.id.leftbrackets);
        Button btnrb = (Button) findViewById(R.id.rightbrackets);

        Button btnsquare = (Button) findViewById(R.id.square);
        Button btncube = (Button) findViewById(R.id.cube);
        Button btnex = (Button) findViewById(R.id.ex);
        Button btn10x = (Button) findViewById(R.id.tenx);

        Button btninverse = (Button) findViewById(R.id.inverse);
        Button btnsqrt = (Button) findViewById(R.id.sqrt);
        Button btnln = (Button) findViewById(R.id.ln);
        Button btnlog10 = (Button) findViewById(R.id.log10x);

        Button btnfactorial = (Button) findViewById(R.id.factorial);
        Button btnsin = (Button) findViewById(R.id.sin);
        Button btncos = (Button) findViewById(R.id.cos);
        Button btntan = (Button) findViewById(R.id.tan);

        Button btnpi = (Button) findViewById(R.id.pi);
        Button btne = (Button) findViewById(R.id.e);
        Button btnswitchs = (Button) findViewById(R.id.switchs);
        Button btnrand = (Button) findViewById(R.id.random);
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentText = (String) textblock.getText();
                int tag = (Integer) view.getTag();
                switch (tag) {
                    case 11:
                        if(currentText.length()!=0)
                        {
                            currentText += "+";
                            break;
                        }
                        break;
                    case 22:
                        if(currentText.length()!=0)
                        {
                            currentText += "-";
                            break;
                        }
                        break;
                    case 33:
                        if(currentText.length()!=0)
                        {
                            currentText += "*";
                            break;
                        }
                        break;
                    case 44:
                        if(currentText.length()!=0)
                        {
                            currentText += "/";
                            break;
                        }
                        break;

                    case 55:
                        currentText = "";
                        break;
                    case 66:
                        if (currentText.length() > 0) {
                            currentText = currentText.substring(0, currentText.length() - 1);
                            break;
                        }
                        break;

                    case 77:
                        if(currentText.length()!=0)
                        {
                            currentText += ".";
                            break;
                        }
                        break;
                    case 88:
                        Pattern pattern = Pattern.compile("^-?\\d+(\\.\\d+)?$");
                        Matcher isNum = pattern.matcher(currentText);
                        if (!isNum.matches()) {
                            break;
                        } else {
                            double num = Double.parseDouble(currentText);
                            num = num / 100;
                            NumberFormat numberFormat = NumberFormat.getInstance();
                            numberFormat.setMaximumFractionDigits(15);
                            numberFormat.setGroupingUsed(false);
                            currentText = numberFormat.format(num);
                            break;
                        }

                    case 99:
                        if (currentText.length() == 0) {
                            break;
                        }
                        if (currentText.substring(currentText.length() - 1).equals(")") && check_function != 0) {
                            currentText = currentText.substring(0, currentText.length() - 1);
                        }
                        currentText = run(currentText);
                        break;
                    case 0:
                        currentText += "0";
                        break;
                    case 1:
                        currentText += "1";
                        break;
                    case 2:
                        currentText += "2";
                        break;
                    case 3:
                        currentText += "3";
                        break;
                    case 4:
                        currentText += "4";
                        break;
                    case 5:
                        currentText += "5";
                        break;
                    case 6:
                        currentText += "6";
                        break;
                    case 7:
                        currentText += "7";
                        break;
                    case 8:
                        currentText += "8";
                        break;
                    case 9:
                        currentText += "9";
                        break;
                }
                textblock.setText(currentText);
            }
        };
        btn0.setTag(0);
        btn0.setOnClickListener(listener);
        btn1.setTag(1);
        btn1.setOnClickListener(listener);
        btn2.setTag(2);
        btn2.setOnClickListener(listener);
        btn3.setTag(3);
        btn3.setOnClickListener(listener);
        btn4.setTag(4);
        btn4.setOnClickListener(listener);
        btn5.setTag(5);
        btn5.setOnClickListener(listener);
        btn6.setTag(6);
        btn6.setOnClickListener(listener);
        btn7.setTag(7);
        btn7.setOnClickListener(listener);
        btn8.setTag(8);
        btn8.setOnClickListener(listener);
        btn9.setTag(9);
        btn9.setOnClickListener(listener);

        btnplus.setTag(11);
        btnplus.setOnClickListener(listener);
        btnminus.setTag(22);
        btnminus.setOnClickListener(listener);
        btntime.setTag(33);
        btntime.setOnClickListener(listener);
        btndiv.setTag(44);
        btndiv.setOnClickListener(listener);

        btnclear.setTag(55);
        btnclear.setOnClickListener(listener);
        btnbackspace.setTag(66);
        btnbackspace.setOnClickListener(listener);

        btnpoint.setTag(77);
        btnpoint.setOnClickListener(listener);
        btnpercent.setTag(88);
        btnpercent.setOnClickListener(listener);
        btnequal.setTag(99);
        btnequal.setOnClickListener(listener);
    }
    @Override
    public void onConfigurationChanged(Configuration config)
    {
        if(config.orientation == Configuration.ORIENTATION_LANDSCAPE)
        {
            setContentView(R.layout.activity_main);
            final TextView textblock = (TextView) findViewById(R.id.cal);
            final Button btn_0 = (Button) findViewById(R.id.bt_0);
            final Button btn_1 = (Button) findViewById(R.id.bt_1);
            final Button btn_2 = (Button) findViewById(R.id.bt_2);
            final Button btn_3 = (Button) findViewById(R.id.bt_3);
            final Button btn_4 = (Button) findViewById(R.id.bt_4);
            final Button btn_5 = (Button) findViewById(R.id.bt_5);
            final Button btn_6 = (Button) findViewById(R.id.bt_6);
            final Button btn_7 = (Button) findViewById(R.id.bt_7);
            final Button btn_8 = (Button) findViewById(R.id.bt_8);
            final Button btn_9 = (Button) findViewById(R.id.bt_9);

            final Button btn_plus = (Button) findViewById(R.id.bt_plus);
            final Button btn_minus = (Button) findViewById(R.id.bt_minus);
            final Button btn_time = (Button) findViewById(R.id.bt_time);
            final Button btn_div = (Button) findViewById(R.id.bt_divide);

            final Button btn_clear = (Button) findViewById(R.id.bt_clear);
            final Button btn_backspace = (Button) findViewById(R.id.bt_backspace);

            final Button btn_point = (Button) findViewById(R.id.bt_point);
            final Button btn_percent = (Button) findViewById(R.id.bt_percent);
            final Button btn_equal = (Button) findViewById(R.id.bt_equal);

            final Button btn_scale = (Button) findViewById(R.id.scale);
            final Button btn_unit = (Button) findViewById(R.id.unit);

            final Button btn_lb = (Button) findViewById(R.id.leftbrackets);
            final Button btn_rb = (Button) findViewById(R.id.rightbrackets);

            final Button btn_square = (Button) findViewById(R.id.square);
            final Button btn_cube = (Button) findViewById(R.id.cube);
            final Button btn_ex = (Button) findViewById(R.id.ex);
            final Button btn_10x = (Button) findViewById(R.id.tenx);

            final Button btn_inverse = (Button) findViewById(R.id.inverse);
            final Button btn_sqrt = (Button) findViewById(R.id.sqrt);
            final Button btn_ln = (Button) findViewById(R.id.ln);
            final Button btn_log10 = (Button) findViewById(R.id.log10x);

            final Button btn_factorial = (Button) findViewById(R.id.factorial);
            final Button btn_sin = (Button) findViewById(R.id.sin);
            final Button btn_cos = (Button) findViewById(R.id.cos);
            final Button btn_tan = (Button) findViewById(R.id.tan);

            final Button btn_pi = (Button) findViewById(R.id.pi);
            final Button btn_e = (Button) findViewById(R.id.e);
            final Button btn_switchs = (Button) findViewById(R.id.switchs);
            final Button btn_rand = (Button) findViewById(R.id.random);

            View.OnClickListener listener1 = new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String currentText = (String) textblock.getText();
                    int tag = (Integer) view.getTag();
                    switch (tag) {
                        case 11:
                            if(currentText.length()!=0)
                            {
                                currentText += "+";
                                break;
                            }
                            break;
                        case 12:
                            if(currentText.length()!=0)
                            {
                                currentText += "-";
                                break;
                            }
                            break;
                        case 13:
                            if(currentText.length()!=0)
                            {
                                currentText += "*";
                                break;
                            }
                            break;
                        case 14:
                            if(currentText.length()!=0)
                            {
                                currentText += "/";
                                break;
                            }
                            break;

                        case 15:
                            currentText = "";
                            break;
                        case 16:
                            if (currentText.length() > 0) {
                                currentText = currentText.substring(0, currentText.length() - 1);
                                break;
                            }
                            break;

                        case 17:
                            if(currentText.length()!=0)
                            {
                                currentText += ".";
                                break;
                            }
                            break;
                        case 18:
                            Pattern pattern = Pattern.compile("^-?\\d+(\\.\\d+)?$");
                            Matcher isNum = pattern.matcher(currentText);
                            if (!isNum.matches()) {
                                break;
                            } else {
                                double num = Double.parseDouble(currentText);
                                num = num / 100;
                                NumberFormat numberFormat = NumberFormat.getInstance();
                                numberFormat.setMaximumFractionDigits(15);
                                numberFormat.setGroupingUsed(false);
                                currentText = numberFormat.format(num);
                                break;
                            }

                        case 19:
                            if (currentText.substring(currentText.length() - 1).equals(")") && check_function != 0) {
                                currentText = currentText.substring(0, currentText.length() - 1);
                            }
                            currentText = run(currentText);
                            break;
                        case 0:
                            currentText += "0";
                            break;
                        case 1:
                            currentText += "1";
                            break;
                        case 2:
                            currentText += "2";
                            break;
                        case 3:
                            currentText += "3";
                            break;
                        case 4:
                            currentText += "4";
                            break;
                        case 5:
                            currentText += "5";
                            break;
                        case 6:
                            currentText += "6";
                            break;
                        case 7:
                            currentText += "7";
                            break;
                        case 8:
                            currentText += "8";
                            break;
                        case 9:
                            currentText += "9";
                            break;
                        case 21:
                            if(currentText.length()!=0)
                            {
                                currentText += "(";
                                break;
                            }
                            break;
                        case 22:
                            if(currentText.length()!=0)
                            {
                                currentText += ")";
                                break;
                            }
                            break;
                        case 23:
                            Pattern pattern2 = Pattern.compile("^-?\\d+(\\.\\d+)?$");
                            Matcher isNum2 = pattern2.matcher(currentText);
                            if (!isNum2.matches()) {
                                break;
                            } else {
                                double num = Double.parseDouble(currentText);
                                num = Math.pow(num,2);
                                NumberFormat numberFormat = NumberFormat.getInstance();
                                numberFormat.setMaximumFractionDigits(15);
                                numberFormat.setGroupingUsed(false);
                                currentText = numberFormat.format(num);
                                break;
                            }
                        case 24:
                            Pattern pattern3 = Pattern.compile("^-?\\d+(\\.\\d+)?$");
                            Matcher isNum3 = pattern3.matcher(currentText);
                            if (!isNum3.matches()) {
                                break;
                            } else {
                                double num = Double.parseDouble(currentText);
                                num = Math.pow(num,3);
                                NumberFormat numberFormat = NumberFormat.getInstance();
                                numberFormat.setMaximumFractionDigits(15);
                                numberFormat.setGroupingUsed(false);
                                currentText = numberFormat.format(num);
                                break;
                            }

                        case 25:
                            Pattern patterne = Pattern.compile("^-?\\d+(\\.\\d+)?$");
                            Matcher isNume = patterne.matcher(currentText);
                            if (!isNume.matches()) {
                                break;
                            } else {
                                double num = Double.parseDouble(currentText);
                                num = Math.pow(Math.E,num);
                                NumberFormat numberFormat = NumberFormat.getInstance();
                                numberFormat.setMaximumFractionDigits(15);
                                numberFormat.setGroupingUsed(false);
                                currentText = numberFormat.format(num);
                                break;
                            }
                        case 26:
                            Pattern patternlog = Pattern.compile("^-?\\d+(\\.\\d+)?$");
                            Matcher isNumlog = patternlog.matcher(currentText);
                            if (!isNumlog.matches()) {
                                break;
                            } else {
                                double num = Double.parseDouble(currentText);
                                num = Math.pow(10,num);
                                NumberFormat numberFormat = NumberFormat.getInstance();
                                numberFormat.setMaximumFractionDigits(15);
                                numberFormat.setGroupingUsed(false);
                                currentText = numberFormat.format(num);
                                break;
                            }
                        case 27:
                            Pattern patterninv = Pattern.compile("^-?\\d+(\\.\\d+)?$");
                            Matcher isNuminv = patterninv.matcher(currentText);
                            if (!isNuminv.matches()) {
                                break;
                            } else {
                                double num = Double.parseDouble(currentText);
                                num = 1/num;
                                NumberFormat numberFormat = NumberFormat.getInstance();
                                numberFormat.setMaximumFractionDigits(15);
                                numberFormat.setGroupingUsed(false);
                                currentText = numberFormat.format(num);
                                break;
                            }
                        case 28:
                            Pattern patternsqrt = Pattern.compile("^-?\\d+(\\.\\d+)?$");
                            Matcher isNumsqrt = patternsqrt.matcher(currentText);
                            if (!isNumsqrt.matches()) {
                                break;
                            } else {
                                double num = Double.parseDouble(currentText);
                                num = Math.sqrt(num);
                                NumberFormat numberFormat = NumberFormat.getInstance();
                                numberFormat.setMaximumFractionDigits(15);
                                numberFormat.setGroupingUsed(false);
                                currentText = numberFormat.format(num);
                                break;
                            }
                        case 29:
                            Pattern patternln = Pattern.compile("^-?\\d+(\\.\\d+)?$");
                            Matcher isNumln = patternln.matcher(currentText);
                            if (!isNumln.matches()) {
                                break;
                            } else {
                                double num = Double.parseDouble(currentText);
                                num = Math.log(num);
                                NumberFormat numberFormat = NumberFormat.getInstance();
                                numberFormat.setMaximumFractionDigits(15);
                                numberFormat.setGroupingUsed(false);
                                currentText = numberFormat.format(num);
                                break;
                            }
                        case 30:
                            Pattern patternlog10 = Pattern.compile("^-?\\d+(\\.\\d+)?$");
                            Matcher isNumlog10 = patternlog10.matcher(currentText);
                            if (!isNumlog10.matches()) {
                                break;
                            } else {
                                double num = Double.parseDouble(currentText);
                                num = Math.log10(num);
                                NumberFormat numberFormat = NumberFormat.getInstance();
                                numberFormat.setMaximumFractionDigits(15);
                                numberFormat.setGroupingUsed(false);
                                currentText = numberFormat.format(num);
                                break;
                            }
                        case 31:
                            Pattern patternfac = Pattern.compile("[0-9]*");
                            Matcher isNumfac = patternfac.matcher(currentText);
                            if (!isNumfac.matches()) {
                                break;
                            } else {
                                double num = Integer.parseInt(currentText);
                                double temp = 1;
                                for(int i=1;i<=num;i++)
                                {
                                    temp=temp*i;
                                }
                                NumberFormat numberFormat = NumberFormat.getInstance();
                                numberFormat.setMaximumFractionDigits(15);
                                numberFormat.setGroupingUsed(false);
                                currentText = numberFormat.format(num);
                                break;
                            }
                        case 32:
                            Pattern patternsin = Pattern.compile("^-?\\d+(\\.\\d+)?$");
                            Matcher isNumsin = patternsin.matcher(currentText);
                            if (!isNumsin.matches()) {
                                break;
                            } else {
                                double num = Double.parseDouble(currentText);
                                num = Math.sin(num);
                                NumberFormat numberFormat = NumberFormat.getInstance();
                                numberFormat.setMaximumFractionDigits(15);
                                numberFormat.setGroupingUsed(false);
                                currentText = numberFormat.format(num);
                                break;
                            }
                        case 33:
                            Pattern patterncos = Pattern.compile("^-?\\d+(\\.\\d+)?$");
                            Matcher isNumcos = patterncos.matcher(currentText);
                            if (!isNumcos.matches()) {
                                break;
                            } else {
                                double num = Double.parseDouble(currentText);
                                num = Math.cos(num);
                                NumberFormat numberFormat = NumberFormat.getInstance();
                                numberFormat.setMaximumFractionDigits(15);
                                numberFormat.setGroupingUsed(false);
                                currentText = numberFormat.format(num);
                                break;
                            }
                        case 34:
                            Pattern patterntan = Pattern.compile("^-?\\d+(\\.\\d+)?$");
                            Matcher isNumtan = patterntan.matcher(currentText);
                            if (!isNumtan.matches()) {
                                break;
                            } else {
                                double num = Double.parseDouble(currentText);
                                num = Math.tan(num);
                                NumberFormat numberFormat = NumberFormat.getInstance();
                                numberFormat.setMaximumFractionDigits(15);
                                numberFormat.setGroupingUsed(false);
                                currentText = numberFormat.format(num);
                                break;
                            }
                        case 35:
                            double num1 = Math.PI;
                            NumberFormat numberFormat1 = NumberFormat.getInstance();
                            numberFormat1.setMaximumFractionDigits(15);
                            numberFormat1.setGroupingUsed(false);
                            currentText = numberFormat1.format(num1);
                            break;
                        case 36:
                            double num2= Math.E;
                            NumberFormat numberFormat2 = NumberFormat.getInstance();
                            numberFormat2.setMaximumFractionDigits(15);
                            numberFormat2.setGroupingUsed(false);
                            currentText = numberFormat2.format(num2);
                            break;
                        case 37:
                            Pattern patternswi = Pattern.compile("^-?\\d+(\\.\\d+)?$");
                            Matcher isNumswi = patternswi.matcher(currentText);
                            if (!isNumswi.matches()) {
                                break;
                            } else {
                                double num = Double.parseDouble(currentText);
                                num = num*(-1);
                                NumberFormat numberFormat = NumberFormat.getInstance();
                                numberFormat.setMaximumFractionDigits(15);
                                numberFormat.setGroupingUsed(false);
                                currentText = numberFormat.format(num);
                                break;
                            }
                        case 38:
                            double num3 = Math.random() * 100;
                            NumberFormat numberFormat3 = NumberFormat.getInstance();
                            numberFormat3.setMaximumFractionDigits(10);
                            numberFormat3.setGroupingUsed(false);
                            currentText = numberFormat3.format(num3);
                            break;
                        case 91:
                            Intent intent = new Intent(MainActivity.this,ScaleTrans.class);
                            startActivity(intent);
                            break;
                        case 92:
                            Intent intent1 = new Intent(MainActivity.this,UnitTrans.class);
                            startActivity(intent1);
                    }
                    textblock.setText(currentText);
                }
            };
            btn_0.setTag(0);
            btn_0.setOnClickListener(listener1);
            btn_1.setTag(1);
            btn_1.setOnClickListener(listener1);
            btn_2.setTag(2);
            btn_2.setOnClickListener(listener1);
            btn_3.setTag(3);
            btn_3.setOnClickListener(listener1);
            btn_4.setTag(4);
            btn_4.setOnClickListener(listener1);
            btn_5.setTag(5);
            btn_5.setOnClickListener(listener1);
            btn_6.setTag(6);
            btn_6.setOnClickListener(listener1);
            btn_7.setTag(7);
            btn_7.setOnClickListener(listener1);
            btn_8.setTag(8);
            btn_8.setOnClickListener(listener1);
            btn_9.setTag(9);
            btn_9.setOnClickListener(listener1);

            btn_plus.setTag(11);
            btn_plus.setOnClickListener(listener1);
            btn_minus.setTag(12);
            btn_minus.setOnClickListener(listener1);
            btn_time.setTag(13);
            btn_time.setOnClickListener(listener1);
            btn_div.setTag(14);
            btn_div.setOnClickListener(listener1);

            btn_clear.setTag(15);
            btn_clear.setOnClickListener(listener1);
            btn_backspace.setTag(16);
            btn_backspace.setOnClickListener(listener1);

            btn_point.setTag(17);
            btn_point.setOnClickListener(listener1);
            btn_percent.setTag(18);
            btn_percent.setOnClickListener(listener1);
            btn_equal.setTag(19);
            btn_equal.setOnClickListener(listener1);

            btn_lb.setTag(21);
            btn_lb.setOnClickListener(listener1);
            btn_rb.setTag(22);
            btn_rb.setOnClickListener(listener1);

            btn_square.setTag(23);
            btn_square.setOnClickListener(listener1);
            btn_cube.setTag(24);
            btn_cube.setOnClickListener(listener1);
            btn_ex.setTag(25);
            btn_ex.setOnClickListener(listener1);
            btn_10x.setTag(26);
            btn_10x.setOnClickListener(listener1);

            btn_inverse.setTag(27);
            btn_inverse.setOnClickListener(listener1);
            btn_sqrt.setTag(28);
            btn_sqrt.setOnClickListener(listener1);
            btn_ln.setTag(29);
            btn_ln.setOnClickListener(listener1);
            btn_log10.setTag(30);
            btn_log10.setOnClickListener(listener1);

            btn_factorial.setTag(31);
            btn_factorial.setOnClickListener(listener1);
            btn_sin.setTag(32);
            btn_sin.setOnClickListener(listener1);
            btn_cos.setTag(33);
            btn_cos.setOnClickListener(listener1);
            btn_tan.setTag(34);
            btn_tan.setOnClickListener(listener1);

            btn_pi.setTag(35);
            btn_pi.setOnClickListener(listener1);
            btn_e.setTag(36);
            btn_e.setOnClickListener(listener1);
            btn_switchs.setTag(37);
            btn_switchs.setOnClickListener(listener1);
            btn_rand.setTag(38);
            btn_rand.setOnClickListener(listener1);

            btn_scale.setTag(91);
            btn_scale.setOnClickListener(listener1);
            btn_unit.setTag(92);
            btn_unit.setOnClickListener(listener1);

        }else {
            setContentView(R.layout.activity_main);
            final TextView textblock = (TextView) findViewById(R.id.cal);
            final Button btn_0 = (Button) findViewById(R.id.bt_0);
            final Button btn_1 = (Button) findViewById(R.id.bt_1);
            final Button btn_2 = (Button) findViewById(R.id.bt_2);
            final Button btn_3 = (Button) findViewById(R.id.bt_3);
            final Button btn_4 = (Button) findViewById(R.id.bt_4);
            final Button btn_5 = (Button) findViewById(R.id.bt_5);
            final Button btn_6 = (Button) findViewById(R.id.bt_6);
            final Button btn_7 = (Button) findViewById(R.id.bt_7);
            final Button btn_8 = (Button) findViewById(R.id.bt_8);
            final Button btn_9 = (Button) findViewById(R.id.bt_9);

            final Button btn_plus = (Button) findViewById(R.id.bt_plus);
            final Button btn_minus = (Button) findViewById(R.id.bt_minus);
            final Button btn_time = (Button) findViewById(R.id.bt_time);
            final Button btn_div = (Button) findViewById(R.id.bt_divide);

            final Button btn_clear = (Button) findViewById(R.id.bt_clear);
            final Button btn_backspace = (Button) findViewById(R.id.bt_backspace);

            final Button btn_point = (Button) findViewById(R.id.bt_point);
            final Button btn_percent = (Button) findViewById(R.id.bt_percent);
            final Button btn_equal = (Button) findViewById(R.id.bt_equal);

            View.OnClickListener listener2 = new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String currentText = (String) textblock.getText();
                    int tag = (Integer) view.getTag();
                    switch (tag) {
                        case 11:
                            if(currentText.length()!=0)
                            {
                                currentText += "+";
                                break;
                            }
                            break;
                        case 12:
                            if(currentText.length()!=0)
                            {
                                currentText += "-";
                                break;
                            }
                            break;
                        case 13:
                            if(currentText.length()!=0)
                            {
                                currentText += "*";
                                break;
                            }
                            break;
                        case 14:
                            if(currentText.length()!=0)
                            {
                                currentText += "/";
                                break;
                            }
                            break;

                        case 15:
                            currentText = "";
                            break;
                        case 16:
                            if (currentText.length() > 0) {
                                currentText = currentText.substring(0, currentText.length() - 1);
                                break;
                            }
                            break;

                        case 17:
                            if(currentText.length()!=0)
                            {
                                currentText += ".";
                                break;
                            }
                            break;
                        case 18:
                            Pattern pattern = Pattern.compile("^-?\\d+(\\.\\d+)?$");
                            Matcher isNum = pattern.matcher(currentText);
                            if (!isNum.matches()) {
                                break;
                            } else {
                                double num = Double.parseDouble(currentText);
                                num = num / 100;
                                NumberFormat numberFormat = NumberFormat.getInstance();
                                numberFormat.setMaximumFractionDigits(15);
                                numberFormat.setGroupingUsed(false);
                                currentText = numberFormat.format(num);
                                break;
                            }

                        case 19:
                            if (currentText.substring(currentText.length() - 1).equals(")") && check_function != 0) {
                                currentText = currentText.substring(0, currentText.length() - 1);
                            }
                            currentText = run(currentText);
                            break;
                        case 0:
                            currentText += "0";
                            break;
                        case 1:
                            currentText += "1";
                            break;
                        case 2:
                            currentText += "2";
                            break;
                        case 3:
                            currentText += "3";
                            break;
                        case 4:
                            currentText += "4";
                            break;
                        case 5:
                            currentText += "5";
                            break;
                        case 6:
                            currentText += "6";
                            break;
                        case 7:
                            currentText += "7";
                            break;
                        case 8:
                            currentText += "8";
                            break;
                        case 9:
                            currentText += "9";
                            break;
                    }
                    textblock.setText(currentText);
                }
            };
            btn_0.setTag(0);
            btn_0.setOnClickListener(listener2);
            btn_1.setTag(1);
            btn_1.setOnClickListener(listener2);
            btn_2.setTag(2);
            btn_2.setOnClickListener(listener2);
            btn_3.setTag(3);
            btn_3.setOnClickListener(listener2);
            btn_4.setTag(4);
            btn_4.setOnClickListener(listener2);
            btn_5.setTag(5);
            btn_5.setOnClickListener(listener2);
            btn_6.setTag(6);
            btn_6.setOnClickListener(listener2);
            btn_7.setTag(7);
            btn_7.setOnClickListener(listener2);
            btn_8.setTag(8);
            btn_8.setOnClickListener(listener2);
            btn_9.setTag(9);
            btn_9.setOnClickListener(listener2);

            btn_plus.setTag(11);
            btn_plus.setOnClickListener(listener2);
            btn_minus.setTag(12);
            btn_minus.setOnClickListener(listener2);
            btn_time.setTag(13);
            btn_time.setOnClickListener(listener2);
            btn_div.setTag(14);
            btn_div.setOnClickListener(listener2);

            btn_clear.setTag(15);
            btn_clear.setOnClickListener(listener2);
            btn_backspace.setTag(16);
            btn_backspace.setOnClickListener(listener2);

            btn_point.setTag(17);
            btn_point.setOnClickListener(listener2);
            btn_percent.setTag(18);
            btn_percent.setOnClickListener(listener2);
            btn_equal.setTag(19);
            btn_equal.setOnClickListener(listener2);
        }

        super.onConfigurationChanged(config);

    }
    public void setData(int tag)
    {
        check_function = tag;
    }
    public String run(String infix) {
        String suffix = toSuffix(infix);
        String result = calculate(suffix);
        return calculate(suffix);
    }
    private static final Map<Character,Integer> PRIORITY_MAP = new HashMap<>();
    private static final String OPERATOR = "*/+-()";
    static{
        PRIORITY_MAP.put('-', 1);
        PRIORITY_MAP.put('+', 1);
        PRIORITY_MAP.put('*', 2);
        PRIORITY_MAP.put('/', 2);
        PRIORITY_MAP.put('(', 0);
    }
    // 中缀表达式转换成后缀表达式
    private String toSuffix(String infix){
        List<String> suffix = new LinkedList<>();
        Stack<Character> stack = new Stack<>();

        // 用于记录字符长度  例如100*2,则记录的len为3 到时候截取字符串的前三位就是数字
        int len = 0;
        for(int i = 0; i < infix.length(); i++){
            char ch = infix.charAt(i);

            // 数字
            if (Character.isDigit(ch) || ch == '.') {
                len++;
            } else if (OPERATOR.indexOf(ch) != -1) {
                // 符号之前的可以截取下来做数字
                if (len > 0) {
                    suffix.add(infix.substring(i-len, i));
                    len = 0;
                }
                // 将左括号放入栈中
                if (ch == '(') {
                    stack.push(ch);
                    continue;
                }
                if (!stack.isEmpty()) {
                    int size = stack.size() - 1;
                    boolean flag = false;

                    // 若当前ch为右括号，则栈里元素从栈顶一直弹出，直到弹出到左括号
                    while(size >= 0 && ch == ')' && stack.peek() != '('){
                        suffix.add(String.valueOf(stack.pop()));
                        size--;
                        flag = true;
                    }

                    // 若取得不是（）内的元素，并且当前栈顶元素的优先级>=对比元素 那就出栈插入队列
                    while(size >= 0 && !flag && PRIORITY_MAP.get(stack.peek()) >= PRIORITY_MAP.get(ch)){
                        suffix.add(String.valueOf(stack.pop()));
                        size--;
                    }
                }

                if (ch != ')') {
                    stack.push(ch);
                }else {
                    stack.pop();
                }
            }
            // 如果已经走到了中缀表达式的最后一位
            if (i == infix.length() - 1) {
                if (len > 0) {
                    suffix.add(infix.substring(i - len + 1, i + 1));
                }

                int size = stack.size() - 1;
                // 一直将栈内 符号全部出栈并且加入队列中
                while(size >= 0) {
                    suffix.add(String.valueOf(stack.pop()));
                    size--;
                }
            }
        }
        return suffix.toString().substring(1, suffix.toString().length()-1);
    }
    // 根据后缀表达式计算结果
    private String calculate(String suffix){
        String [] arr = suffix.split(",");
        Stack<String> stack = new Stack<>();

        for (int i = 0; i < arr.length; i++) {
            switch (arr[i].trim()) {
                case "+":
                    double a = Double.parseDouble(stack.pop()) + Double.parseDouble(stack.pop());
                    stack.push(String.valueOf(a));
                    break;
                case "-":
                    double b = Double.parseDouble(stack.pop()) - Double.parseDouble(stack.pop());
                    stack.push(String.valueOf(-b));
                    break;
                case "*":
                    double c = Double.parseDouble(stack.pop()) * Double.parseDouble(stack.pop());
                    stack.push(String.valueOf(c));
                    break;
                case "/":
                    double first = Double.parseDouble(stack.pop());
                    double d = Double.parseDouble(stack.pop()) / first;
                    stack.push(String.valueOf(d));
                    break;
                default:
                    stack.push(arr[i].trim());
                    break;
            }
        }
        if(stack.size() == 1)
        {
            return stack.pop();
        }
        else
        {
            Toast.makeText(this,"Input Error",Toast.LENGTH_SHORT).show();
            return "";
        }
    }
}